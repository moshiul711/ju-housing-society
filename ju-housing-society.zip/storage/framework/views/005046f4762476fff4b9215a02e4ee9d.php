

<?php $__env->startSection('main-content'); ?>
    <section class="ls page_portfolio section_padding_top_50 section_padding_bottom_50">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4">
                    <ul class="list2 color2 checklist greylinks">
                        <li>
                            <a target="_blank" href="<?php echo e(asset($form->form)); ?>"><?php echo e($form->title); ?></a>
                        </li>
                    </ul>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ju-housing-society\resources\views/front/home/forms.blade.php ENDPATH**/ ?>