

<?php $__env->startSection('main-content'); ?>
    <div class="col-lg-12 col-md-12">
        <div class="page-header">
            <div>
                <h1 class="page-title">Invoice</h1>
            </div>
            <div class="ms-auto pageheader-btn">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Invoice</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Create</li>
                </ol>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card card-body">
                <div class="container-login100">
                    <div class="wrap-login100 p-0">
                        <div class="card-body">
                            <form action="<?php echo e(route('invoice.store')); ?>" method="post" class="login100-form validate-form">
                                <?php echo csrf_field(); ?>
                                <div class="wrap-input100 validate-input">
                                    <label for="" class=""> Select Member No : </label>
                                    <select name="teacher_id" class="form-control input100" id="">
                                        <option value="">---Select Member No---</option>
                                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->member_no); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="wrap-input100 validate-input">
                                    <label for="" class=""> Select Service Year : </label>
                                    <select name="service_detail_id" class="form-control input100" id="">
                                        <option value="">---Select Service Year---</option>
                                        <?php $__currentLoopData = $service_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($service_detail->id); ?>"><?php echo e($service_detail->service_year); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="container-login100-form-btn">
                                    <button type="submit" class="login100-form-btn btn-primary">
                                        Assign Member
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
        
            
                

                    
                        
                        
                            
                            
                                
                                
                                    
                                
                            

                            
                            
                                
                                
                                    
                                
                            

                            

                        

                        
                            
                            
                                
                            

                            
                            
                                
                            
                        

                        
                            
                            
                                
                            
                            
                            
                                
                            
                        

                        
                            
                            
                                
                            

                            
                            
                                
                            
                        

                        
                            
                            
                                
                            

                            
                            
                                
                            
                        

                        
                            
                            
                                
                            

                            
                            
                                
                            
                        

                        
                            
                            
                                
                            

                            
                            
                                
                            
                        

                        
                            
                            
                                
                            
                        
                        
                            
                            
                                
                            
                        
                    
                
            
        
    



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ju-housing-society\resources\views/admin/payment_invoice/create.blade.php ENDPATH**/ ?>