

<?php $__env->startSection('main-content'); ?>
    <section id="about" class="ls section_padding_top_110 columns_padding_30">
        <div class="container">
            <div class="row">
                <div class="col-md-4" data-animation="fadeInUp" data-delay="600">
                    <div class="embed-responsive embed-responsive-3by2"> <a href="https://www.youtube.com/embed/xKxrkht7CpY" class="embed-placeholder">
                            <img src="<?php echo e(asset('/')); ?>front/images/gallery/01.jpg" alt="">
                        </a> </div>
                </div>
                <div class="col-md-8" data-animation="fadeInRight" data-delay="300">
                    <h2 class="section_header color4"> What is Our Co-Operative Housing Society </h2>
                    <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="section-excerpt grey">
                        <?php echo $about->description; ?>

                    </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ju-housing-society\resources\views/front/home/about.blade.php ENDPATH**/ ?>