

<?php $__env->startSection('main-content'); ?>
    <section class="section_padding_top_50 section_padding_bottom_50 columns_padding_25">
        <div class="container">
            <div class="row">
                <div class="col-md-2 with_border">
                    <div class="widget widget_recent_posts">
                        <ul class="list-unstyled greylinks">
                            <li class="media"> <i class="fa fa-dashboard highlight rightpadding_5" aria-hidden="true"></i>
                                <a href="<?php echo e(route('teacher.dashboard')); ?>" style="color: black;">Dashboard</a>
                            </li>

                            <li class="media"> <i class="fa fa-user highlight rightpadding_5" aria-hidden="true"></i>
                                <a href="<?php echo e(route('teacher.profile')); ?>" style="color: black;">Profile</a>
                            </li>

                            <li class="media"> <i class="fa fa-paypal highlight rightpadding_5" aria-hidden="true"></i>
                                <a href="<?php echo e(route('teacher.payment')); ?>" style="color: black;">Payment History</a>
                            </li>

                            <li class="media "> <i class="fa fa-group highlight rightpadding_5" aria-hidden="true"></i>
                                <a href="<?php echo e(route('teachers')); ?>" class="section_padding_bottom_5" style="color: black;">Member Lists</a>
                            </li>

                            
                            
                            
                        </ul>
                    </div>
                </div>
                <?php if(Session('message')): ?>
                <p class="text-center text-success"><?php echo e(Session('message')); ?></p>
                <?php endif; ?>
                <div class="col-md-10">
                    <section class="ls section_padding_bottom_50 columns_padding_30">
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-12">
                                    <article class="vertical-item content-padding big-padding text-center">
                                        <form action="<?php echo e(route('teacher.profile.update',['id'=>$teacher->id,'name'=>$teacher->name])); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="row text-left">
                                                <div class="col-md-12 form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($teacher->name); ?>" name="name" placeholder="Enter Name" required>
                                                </div>
                                                <div class="col-md-12 form-group">
                                                    <input type="email" class="form-control" value="<?php echo e($teacher->email); ?>" name="email" placeholder="Enter Email" required>
                                                </div>
                                                <div class="col-md-12 form-group">
                                                    <input type="tel" class="form-control" value="<?php echo e($teacher->phone); ?>" name="phone" placeholder="Enter phone" required>
                                                </div>
                                                <div class="col-md-12 form-group">
                                                    <textarea class="form-control" name="address" placeholder="Enter Address"><?php echo e($teacher->address); ?></textarea>
                                                </div>
                                                <div class="col-md-12 form-group">
                                                    <textarea id="summernote" class="form-control" name="about" placeholder="About Yourself" ><?php echo $teacher->about; ?></textarea>
                                                </div>
                                                <div class="col-md-12 form-group">
                                                    
                                                    <input type="file" class="form-control" name="image">
                                                </div>

                                                <div class="col-md-12 form-group">
                                                    <button class="theme_button color2 margin_0" style="width: 100%">Update Profile</button>
                                                </div>

                                            </div>
                                        </form>
                                    </article>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ju-housing-society\resources\views/teacher/profile.blade.php ENDPATH**/ ?>