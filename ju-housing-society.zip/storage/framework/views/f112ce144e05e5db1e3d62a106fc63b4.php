

<?php $__env->startSection('main-content'); ?>
    <section class="ls page_portfolio section_padding_top_100 section_padding_bottom_100">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="isotope_container isotope row masonry-layout columns_margin_bottom_20" data-filters=".isotope_filters">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-<?php echo e($image->id); ?>">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset($image->image)); ?>" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="<?php echo e(asset($image->image)); ?>"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html"><?php echo e($image->title); ?></a> </h4>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ju-housing-society\resources\views/front/home/photo.blade.php ENDPATH**/ ?>