

<?php $__env->startSection('main-content'); ?>
    <section class="ls page_portfolio section_padding_top_100 section_padding_bottom_100">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="isotope_container isotope row masonry-layout columns_margin_bottom_20" data-filters=".isotope_filters">
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-1">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset('/')); ?>front/images/gallery/01.jpg" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="images/gallery/01.jpg"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html">Consetetur sadipscing elitr, sed diam nonumy</a> </h4>
                                </div>
                            </div>
                        </div>
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-2">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset('/')); ?>front/images/gallery/02.jpg" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="images/gallery/02.jpg"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html">Consetetur sadipscing elitr, sed diam nonumy</a> </h4>
                                </div>
                            </div>
                        </div>
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-3">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset('/')); ?>front/images/gallery/03.jpg" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="<?php echo e(asset('/')); ?>front/images/gallery/03.jpg"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html">Consetetur sadipscing elitr, sed diam nonumy</a> </h4>
                                </div>
                            </div>
                        </div>
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-4">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset('/')); ?>front/images/gallery/04.jpg" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="<?php echo e(asset('/')); ?>front/images/gallery/04.jpg"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html">Consetetur sadipscing elitr, sed diam nonumy</a> </h4>
                                </div>
                            </div>
                        </div>
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-1">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset('/')); ?>front/images/gallery/05.jpg" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="<?php echo e(asset('/')); ?>front/images/gallery/05.jpg"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html">Consetetur sadipscing elitr, sed diam nonumy</a> </h4>
                                </div>
                            </div>
                        </div>
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-2">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset('/')); ?>front/images/gallery/06.jpg" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="<?php echo e(asset('/')); ?>front/images/gallery/06.jpg"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html">Consetetur sadipscing elitr, sed diam nonumy</a> </h4>
                                </div>
                            </div>
                        </div>
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-3">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset('/')); ?>front/images/gallery/07.jpg" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="<?php echo e(asset('/')); ?>front/images/gallery/07.jpg"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html">Consetetur sadipscing elitr, sed diam nonumy</a> </h4>
                                </div>
                            </div>
                        </div>
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-4">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset('/')); ?>front/images/gallery/08.jpg" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="<?php echo e(asset('/')); ?>front/images/gallery/08.jpg"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html">Consetetur sadipscing elitr, sed diam nonumy</a> </h4>
                                </div>
                            </div>
                        </div>
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-1">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset('/')); ?>front/images/gallery/09.jpg" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="<?php echo e(asset('/')); ?>front/images/gallery/09.jpg"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html">Consetetur sadipscing elitr, sed diam nonumy</a> </h4>
                                </div>
                            </div>
                        </div>
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-2">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset('/')); ?>front/images/gallery/10.jpg" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="<?php echo e(asset('/')); ?>front/images/gallery/10.jpg"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html">Consetetur sadipscing elitr, sed diam nonumy</a> </h4>
                                </div>
                            </div>
                        </div>
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-3">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset('/')); ?>front/images/gallery/11.jpg" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="<?php echo e(asset('/')); ?>front/images/gallery/11.jpg"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html">Consetetur sadipscing elitr, sed diam nonumy</a> </h4>
                                </div>
                            </div>
                        </div>
                        <div class="isotope-item col-lg-4 col-md-6 col-sm-12 category-4">
                            <div class="vertical-item gallery-item content-absolute text-center ds">
                                <div class="item-media"> <img src="<?php echo e(asset('/')); ?>front/images/gallery/12.jpg" alt="">
                                    <div class="media-links">
                                        <div class="links-wrap"> <a class="p-view prettyPhoto " title="" data-gal="prettyPhoto[gal]" href="<?php echo e(asset('/')); ?>front/images/gallery/12.jpg"></a> </div>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h4> <a href="gallery-single.html">Consetetur sadipscing elitr, sed diam nonumy</a> </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- eof .isotope_container.row -->
                    
                        
                            
                                
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                
                            
                        
                    
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ju-housing-society\resources\views/front/home/photo.blade.php ENDPATH**/ ?>