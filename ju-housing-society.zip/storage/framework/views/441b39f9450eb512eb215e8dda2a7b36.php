

<?php $__env->startSection('main-content'); ?>
    <section class="ls page_portfolio section_padding_top_50 section_padding_bottom_100">
        <div class="container">
            <div class="row">

                    <h3>Executive Committee Member(s):</h3>
                <?php $__currentLoopData = $committees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $committee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                        <article class="vertical-item content-padding big-padding bottom_color_border">
                            <div class="item-media"> <img src="<?php echo e(asset($committee->image)); ?>" alt=""> </div>
                            <div class="item-content">
                                <header class="entry-header">
                                    <h3 class="entry-title small bottommargin_0"> <a href="#"><?php echo e($committee->name); ?></a> </h3> <span class="small-text highlight"><?php echo e($committee->role); ?></span> </header>
                                <p class="member-social greylinks">
                                    <?php echo e($committee->phone); ?>

                                </p>
                            </div>
                        </article>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ju-housing-society\resources\views/front/home/committee.blade.php ENDPATH**/ ?>