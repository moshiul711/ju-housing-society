

<?php $__env->startSection('main-content'); ?>
    <div class="col-lg-12 col-md-12">
        <div class="page-header">
            <div>
                <h1 class="page-title">Service Details</h1>
            </div>
            <div class="ms-auto pageheader-btn">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Service Details</a></li>
                    <li class="breadcrumb-item active" aria-current="page">List</li>
                </ol>
            </div>
        </div>
    </div>
    <div class="row row-sm">
        <div class="col-lg-12">
            <div class="card custom-card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table border text-nowrap text-md-nowrap table-hover" id="basic-datatable">
                            <thead>
                            <tr>
                                <th>Service Year</th>
                                <th>Total Charge</th>
                                <th>Membership Fees</th>
                                <th>Share Certificate Fees</th>
                                <th>Land Value</th>
                                <th>Development Fees</th>
                                <th>Electric Line Fees</th>
                                <th>Savings Deposit Fees</th>
                                <th>Administration Fees</th>
                                <th>Plot Transfer Fees</th>
                                <th>Garbage Bill</th>
                                <th>Employee Welfare Trust</th>
                                <th>Late Fees</th>
                                <th>Service Charge</th>
                                <th>Others Bill</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $service_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($detail->service_year); ?></td>
                                <td><?php echo e(number_format($detail->total)); ?></td>
                                <td><?php echo e($detail->membership); ?></td>
                                <td><?php echo e($detail->share_certificate); ?></td>
                                <td><?php echo e($detail->land_value); ?></td>
                                <td><?php echo e($detail->development); ?></td>
                                <td><?php echo e($detail->electric_line); ?></td>
                                <td><?php echo e($detail->savings_deposit); ?></td>
                                <td><?php echo e($detail->administration); ?></td>
                                <td><?php echo e($detail->plot_transfer); ?></td>
                                <td><?php echo e($detail->garbage); ?></td>
                                <td><?php echo e($detail->employee_welfare); ?></td>
                                <td><?php echo e($detail->late_fees); ?></td>
                                <td><?php echo e($detail->service); ?></td>
                                <td><?php echo e($detail->others); ?></td>
                                <td>
                                    <a href="<?php echo e(route('service.details.edit',$detail->id)); ?>" class="btn btn-warning">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                </td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ju-housing-society\resources\views/admin/service_details/manage.blade.php ENDPATH**/ ?>