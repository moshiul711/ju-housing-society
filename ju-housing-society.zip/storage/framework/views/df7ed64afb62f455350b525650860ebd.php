

<?php $__env->startSection('main-content'); ?>
    <section class="ls page_portfolio section_padding_top_100 section_padding_bottom_100">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3>Community Services:</h3>
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs color2" role="tablist">
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li  class=<?php echo e($service->id == 1 ? "active" :''); ?>><a href="#tab<?php echo e($service->id); ?>" role="tab" data-toggle="tab"></i> <?php echo e($service->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content top-color-border color2">
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade active" id="tab<?php echo e($service->id); ?>">
                            <?php echo $service->description; ?>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ju-housing-society\resources\views/front/home/services.blade.php ENDPATH**/ ?>