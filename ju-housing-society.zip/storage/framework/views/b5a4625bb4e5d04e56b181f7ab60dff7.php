

<?php $__env->startSection('main-content'); ?>
    <div class="col-lg-12 col-md-12">
        <div class="page-header">
            <div>
                <h1 class="page-title">Membership</h1>
            </div>
            <div class="ms-auto pageheader-btn">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add Membership</li>
                </ol>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card card-body">
                <div class="container-login100">
                    <div class="wrap-login100 p-0">
                        <div class="card-body">
                            <form action="<?php echo e(route('member.store')); ?>" method="post" class="login100-form validate-form">
                                <?php echo csrf_field(); ?>
                                <div class="wrap-input100 validate-input">
                                    <label for="" class="">Member Name : </label>
                                    <input type="text" class="form-control input100" name="name">
                                </div>

                                <div class="wrap-input100 validate-input">
                                    <label for="" class="">Membership No : </label>
                                    <input type="text" class="form-control input100" name="member_no">
                                </div>
                                <div class="wrap-input100 validate-input">
                                    <label for="" class="">Plot No : </label>
                                    <input type="text" class="form-control input100" name="plot_no">
                                </div>

                                <div class="container-login100-form-btn">
                                    <button type="submit" class="login100-form-btn btn-primary">
                                        Add Member
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
        
            
                

                    
                        
                        
                            
                            
                                
                                
                                    
                                
                            

                            
                            
                                
                                
                                    
                                
                            

                            

                        

                        
                            
                            
                                
                            

                            
                            
                                
                            
                        

                        
                            
                            
                                
                            
                            
                            
                                
                            
                        

                        
                            
                            
                                
                            

                            
                            
                                
                            
                        

                        
                            
                            
                                
                            

                            
                            
                                
                            
                        

                        
                            
                            
                                
                            

                            
                            
                                
                            
                        

                        
                            
                            
                                
                            

                            
                            
                                
                            
                        

                        
                            
                            
                                
                            
                        
                        
                            
                            
                                
                            
                        
                    
                
            
        
    



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ju-housing-society\resources\views/admin/member/create.blade.php ENDPATH**/ ?>