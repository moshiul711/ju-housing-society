


<?php $__env->startSection('main-content'); ?>

    <section class="section_padding_top_50 section_padding_bottom_50 columns_padding_25">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card" style="width: 50%; margin: auto">
                        <form action="<?php echo e(route('teacher.login')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12 form-group">
                                    <input type="text" class="form-control" name="email_phone" placeholder="Enter Phone Number or Email" required>
                                </div>
                                <div class="col-md-12 form-group">
                                    <input type="password" class="form-control" name="password" placeholder="Enter Password" required>
                                </div>

                                <div class="col-md-12 form-group">
                                    <button class="theme_button color2 margin_0" style="width: 100%">Login</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ju-housing-society\resources\views/teacher/login.blade.php ENDPATH**/ ?>