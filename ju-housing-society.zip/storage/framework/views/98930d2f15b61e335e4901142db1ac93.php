

<?php $__env->startSection('main-content'); ?>
    <div class="col-lg-12 col-md-12">
        <div class="page-header">
            <div>
                <h1 class="page-title">Charges & Fees</h1>
            </div>
            <div class="ms-auto pageheader-btn">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Charges</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Manage</li>
                </ol>
            </div>
        </div>
    </div>
    <div class="row row-sm">
        <div class="col-lg-12">
            <div class="card custom-card">
                <div class="card-header border-bottom">
                    <h3 class="card-title">Hoverable Rows Table</h3>
                </div>
                <div class="card-body">
                    <p class="text-muted">To enable hover state on table rows.</p>
                    <div class="table-responsive">
                        <table class="table border text-nowrap text-md-nowrap table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Salary</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>1</td>
                                <td>Kevin Powell</td>
                                <td>Business Development Associator</td>
                                <td>$50,300</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Mark Ronson</td>
                                <td>Sales Manager</td>
                                <td>$45,500</td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Katy Perry</td>
                                <td>Data Analyst</td>
                                <td>$425,500</td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>Pam Podrick</td>
                                <td>Python Developer</td>
                                <td>$415,900</td>
                            </tr>
                            <tr>
                                <td>5</td>
                                <td>Sandy Orell</td>
                                <td>Backed Developer</td>
                                <td>$95,900</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\ju-housing-society\resources\views/admin/charge/manage.blade.php ENDPATH**/ ?>